<template>
  <div id="app">
    <!-- 一级路由占位 -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App',
  data() {
    return {}
  },
}
</script>
